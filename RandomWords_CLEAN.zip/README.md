Чистый Android-проект RandomWords. ZIP внутри проекта не используется. Сборка выполняется GitHub Actions.
