package com.example.randomwords
import android.app.Activity
import android.os.Bundle
import android.content.*
import android.net.Uri
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity: Activity() {
 private lateinit var words: EditText
 private lateinit var amount: EditText
 private lateinit var result: TextView
 private val prefs by lazy { getSharedPreferences("data",0) }
 override fun onCreate(b: Bundle?) {
  super.onCreate(b)
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,28,28,28)}
  fun add(v:android.view.View){root.addView(v,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=16}}
  add(TextView(this).apply{text="Генератор случайных слов";textSize=24f})
  words=EditText(this).apply{hint="Вставьте список слов";minLines=8;gravity=Gravity.TOP;setText(prefs.getString("words",""))};add(words)
  add(Button(this).apply{text="Загрузить TXT";setOnClickListener{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="text/plain";addCategory(Intent.CATEGORY_OPENABLE)},10)}})
  amount=EditText(this).apply{hint="Количество слов";inputType=InputType.TYPE_CLASS_NUMBER;setText(prefs.getString("amount","12"))};add(amount)
  add(Button(this).apply{text="СГЕНЕРИРОВАТЬ";setOnClickListener{generate()}})
  result=TextView(this).apply{text="Здесь появится результат";textSize=20f;setTextIsSelectable(true)};add(result)
  add(Button(this).apply{text="КОПИРОВАТЬ";setOnClickListener{if(result.text.toString()!="Здесь появится результат"){val c=getSystemService(CLIPBOARD_SERVICE) as ClipboardManager;c.setPrimaryClip(ClipData.newPlainText("words",result.text));Toast.makeText(this@MainActivity,"Скопировано",Toast.LENGTH_SHORT).show()}}})
  setContentView(root)
 }
 private fun generate(){
  val list=words.text.toString().split(Regex("[\\s,;]+")).map{it.trim()}.filter{it.isNotEmpty()}.distinct()
  val n=amount.text.toString().toIntOrNull()?:12
  if(n<=0||list.size<n){Toast.makeText(this,"Нужно минимум $n уникальных слов",Toast.LENGTH_SHORT).show();return}
  prefs.edit().putString("words",words.text.toString()).putString("amount",n.toString()).apply()
  result.text=list.shuffled().take(n).joinToString(" ")
 }
 override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==10&&c==RESULT_OK){val u:Uri=d?.data?:return;contentResolver.openInputStream(u)?.bufferedReader()?.use{words.setText(it.readText())}}}
}
