package com.example.randomwords

import android.app.Activity
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var words: EditText
    private lateinit var amount: EditText
    private lateinit var result: TextView

    private val prefs by lazy { getSharedPreferences("data", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
        }

        fun add(view: android.view.View) {
            root.addView(
                view,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = 16 }
            )
        }

        add(TextView(this).apply {
            text = "Генератор случайных слов"
            textSize = 24f
        })

        words = EditText(this).apply {
            hint = "Вставьте список слов"
            minLines = 8
            gravity = Gravity.TOP
            setText(prefs.getString("words", ""))
        }
        add(words)

        add(Button(this).apply {
            text = "ЗАГРУЗИТЬ TXT"
            setOnClickListener {
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        type = "text/plain"
                        addCategory(Intent.CATEGORY_OPENABLE)
                    },
                    10
                )
            }
        })

        amount = EditText(this).apply {
            hint = "Количество слов"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(prefs.getString("amount", "12"))
        }
        add(amount)

        add(Button(this).apply {
            text = "СГЕНЕРИРОВАТЬ"
            setOnClickListener { generate() }
        })

        result = TextView(this).apply {
            text = "Здесь появится результат"
            textSize = 20f
            setTextIsSelectable(true)
        }
        add(result)

        add(Button(this).apply {
            text = "КОПИРОВАТЬ"
            setOnClickListener {
                val text = result.text.toString()
                if (text.isNotBlank() && text != "Здесь появится результат") {
                    val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("words", text))
                    Toast.makeText(this@MainActivity, "Скопировано", Toast.LENGTH_SHORT).show()
                }
            }
        })

        setContentView(root)
    }

    private fun generate() {
        val list = words.text.toString()
            .split(Regex("[\\s,;]+"))
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .distinct()

        val n = amount.text.toString().toIntOrNull() ?: 12

        if (n <= 0) {
            Toast.makeText(this, "Количество должно быть больше нуля", Toast.LENGTH_SHORT).show()
            return
        }

        if (list.size < n) {
            Toast.makeText(this, "Нужно минимум $n уникальных слов", Toast.LENGTH_SHORT).show()
            return
        }

        prefs.edit()
            .putString("words", words.text.toString())
            .putString("amount", n.toString())
            .apply()

        result.text = list.shuffled().take(n).joinToString(" ")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 10 && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            contentResolver.openInputStream(uri)?.bufferedReader()?.use {
                words.setText(it.readText())
            }
        }
    }
}
